#!/usr/bash

mrh="\033[31m"
kun="\033[33m"
kunt="\033[33;1m"
ijo="\033[32m"
wet="\033[97;1m"
nat="\033[0m"
bir="\033[90;36m"

read -p "- Date: " dt;
read -p "- Page: " tgl;
read -p "- To Page: " stgl;
read -p "- Save In: " sv
echo ''
for((i=$tgl;i<=$stgl;i++))
do
c=$(curl -s "https://www.uidomains.com/browse-daily-domains-difference/$i" -L | grep -oP "<li>(.*?)</li>" | cut -d "<" -f2 | cut -d ">" -f2 | sed "s/A query limit of UNLIMITED domains per search. Free is only 200.//" | sed "s/Upload your own lists that no one sees.//" | sed "s/We believe we built the most customizable domain search tool.//" | sed "s/No logging of domains.//" | sed "s/Includes a 1 day trial//" | sed "s/Password Access//" | sed "s/Free Support//" | uniq)
cu=$(echo "$c" | wc -l)
if [[ $c =~ '.' ]];
then
echo "$c" >> result/$sv
echo -e ${ijo}"-> ${nat}[${ijo}SUCCES${nat}] Get $cu Domain In Page $i"
else
echo -e ${mrh}"-> ${nat}[${ijo}FAILED${nat}] Get Domain In Page $i"
fi
done
echo -e ${mrh}"-> ${nat}[${kun}Result Save In result/$sv${nat}]"

