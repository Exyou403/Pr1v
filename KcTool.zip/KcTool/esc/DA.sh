#!/bin/bash

mrh="\033[31m"
kun="\033[33m"
kunt="\033[33;1m"
ijo="\033[32m"
wet="\033[97;1m"
nat="\033[0m"
bir="\033[90;36m"

dapa(){
echo ""
read -p "  Input List: " list;
echo ''
while read line; do
c=$(curl --silent --data-urlencode "domain=$line" --data-urlencode "submit=Get+Website+Metrics" "https://www.countingcharacters.com/website-authority-checker")
if [[ $c ]];
then
d=$(echo $c | grep -Po "Domain Authority: <span style='color:#2d3436''>[0-9]*" | cut -d ">" -f2)
p=$(echo $c | grep -Po "Page Authority: <span style='color:#2d3436''>[0-9]*" | cut -d ">" -f2)
echo -e "-> ${ijo}Site ${mrh}~ ${nat}$line \n   DA: ${kun}$d ${nat}• PA: ${kun}$p"
else
echo -e $nat "-> Site: ${line} ${mrh} FAILED!!!\n"
fi
done < $list
echo ''
}
dapa
