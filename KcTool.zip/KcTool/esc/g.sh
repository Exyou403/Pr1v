blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
yesgreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'
echo ""
read -p "Input Domains: " domain
curl -s https://tranco-list.eu/download/65GX/10000000000000000000000000000000000 | cut -d "," -f2 | grep -F ".$domain" >> result/ResultList.$domain.txt &
echo "Grabbing..."
sleep 3
tail -f result/ResultList.$domain.txt
