#!/usr/bash

mrh="\033[31m"
kun="\033[33m"
kunt="\033[33;1m"
ijo="\033[32m"
wet="\033[97;1m"
nat="\033[0m"
bir="\033[90;36m"

echo ""
read -p "- Start Page: " pek;
read -p "- End Page: " topek;
read -p "- Save In: " sv;
echo ' '
for((i=$pek;i<=$topek;i++))
do
cuk=$(curl -s "https://websitedetection.com/web-site-list-$i" -L | grep -oP '<a href="(.*?)" target="_blank" rel="nofollow">(.*?)</a>' | cut -d "<" -f2 | cut -d ">" -f2)
cu=$(echo "$cuk" | wc -l)
if [[ $cuk =~ '.' ]];
then
echo "$cuk" >> $sv
echo -e ${nat}"-> [${ijo}SUCCES${nat}] Succes Grabbed $cu Domain In Page $i"
else
echo -e ${nat} "-> [${mrh}FAILED${nat}] Failed Grabbed In Page $i"
fi
done
sleep 0.1
echo -e ${mrh}"-> ${nat}[${kun}Result Save In $sv${nat}] <-"

