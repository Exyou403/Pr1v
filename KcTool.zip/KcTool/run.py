# coding=utf-8

"""
info tools © 2022 create by KingClone
 support : Mr x two - BE455 - KX - All friends.
  report bug  <antsec876@gmail.com>
"""

from os import system as sy
from time import sleep as wktu
from random import shuffle
from ran import *
import sys, requests


# Colour
abu="\033[1;30m"
mrh="\033[1;31m"
bru="\033[1;34m"
n="\033[0m"


menu="""
      {}•{}Menu_

 {}01. {}Revip Unlimited
 {}02. {}Grabber (date/month/year/page/domain)
 {}03. {}Grabber Domain + IP Narget/id/il
 {}04. {}Grabber Domain Date + Page
 {}05. {}Grabber Domain Page
 {}06. {}Grabber Unlimited
 {}07. {}Webdav
 {}08. {}Cek DA/PA
 {}00. {}Info Tools

""".format(n,bru,abu,n,abu,n,abu,n,abu,n,abu,n,abu,n,abu,n,abu,n,abu,n)


def main():
    bAnner()
    print menu
    pilih()

def bAnner():
    shuffle(banner)
    print (banner[0])

def pilih():
    pilih = raw_input(" Choose : ")
    if pilih == "01" or pilih == "1":
        sy("python2 esc/r.py")
    elif pilih == "02" or pilih == "2":
        sy("bash esc/gb.sh")
    elif pilih == "03" or pilih == "3":
        sy("bash esc/gajsjsjbdanajiahshssb")
    elif pilih == "04" or pilih == "4":
        sy("bash esc/grabDomainDP.sh")
    elif pilih == "05" or pilih == "5":
        sy("bash esc/GrabDomainPage.sh")
    elif pilih == "06" or pilih == "6":
        sy("bash esc/g.sh")
    elif pilih == "07" or pilih == "7":
        sy("bash esc/Wb.sh")
    elif pilih == "08" or pilih == "8":
        sy("bash esc/DA.sh")
    else:
        print " Command not found! "
        pilih()

def ulang():
    back = raw_input("\n {}Back to home? (Y/n) : ".format(n))
    if back == "y" or back == "Y":
        main()
    if back == "n" or back == "N":
        sys.exit(" Semoga harimu menyenangkan😇 \n")

if __name__ == '__main__':
     main()
